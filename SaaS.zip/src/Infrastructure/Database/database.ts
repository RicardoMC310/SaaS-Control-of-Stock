import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "@/Infrastructure/generated/prisma/client";
import env from "@/Infrastructure/Config/env";

const adapter = new PrismaPg({ connectionString: env.DATABASE_URL });
const prisma = new PrismaClient({ adapter });

export default prisma;